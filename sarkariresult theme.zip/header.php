<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>
<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php endif; ?>
<meta name="description" content="reoranjan : sarkarinaukaricom.com provides you all the latest govt/Sarkari Results, Govt Jobs, Admit Cards, in various sectors such as Railway, Bank, CDS, NDA, SSC, Army, Navy, Police, RSMSSB, UPPSC, UPSSSC and more jobalerts only one place."></meta>
<meta name="keywords" content=" Last Date, Admit Cards, Sarkari Result, latest sarkari results, Sarkariresult, Sarkari JOBS, Sarkariresults"></meta>
<meta name="rating" content="general" />
<meta http-equiv="content-language" content="en" />
<meta name="distribution" content="global" />
<meta name="robots" content="index, follow" />
<link href="<?php echo get_stylesheet_uri(); ?>" rel="stylesheet" type="text/css"></link>
</head>
<body>
<div align="center">
<div id="header">
<div id="head-title"><?php bloginfo( 'name' ); ?><br /></div>
<font size="+1" color="#ffffff"><b><?php bloginfo( 'url' ); ?></b></font>
</div>
<div id="menu">
<ul class="menu">
<li><a href="#" class="parent"><span>Home</span></a></li>
<li><a href="https://sarkarinaukaricom.com/latest-jobs-sarkari-naukri-com/" class="parent"><span>All India Jobs</span></a></li>
<li><a href="https://sarkarinaukaricom.com" class="parent"><span>Answer Key</span></a></li>
<li><a href="https://sarkarinaukaricom.com" class="parent"><span>Latest Jobs</span></a></li>
<li><a href="https://sarkarinaukaricom.com/sarkari-admit-card-exam-admit-card/" class="parent"><span>Admit Card</span></a></li>
<li><a href="https://sarkarinaukaricom.com" class="parent"><span>Results</span></a></li>
</a></li>
<li><a href="https://sarkarinaukaricom.com/syllabus/" class="parent"><span>Syllabus</span>
	<li><a href="https://sarkarinaukaricom.com" class="parent"><span>Railway Jobs </span></a></li>
</a></li>
<li><a href="https://sarkarinaukaricom.com" class="parent"><span> Banking Jobs</span>
<li><a href="https://sarkarinaukaricom.com" class="parent"><span>contact us</span></a>
<li>
</li>
</ul>
<br>
</div>
</div>
<br>
<br>
<div align="center">
<div id="marquee0" align="center">
	<?php $i = 1; 

$custom_query = new WP_Query('cat=8'); // exclude category 9
while($custom_query->have_posts() && $i < 3) : $custom_query->the_post(); ?>
<a href="<?php the_permalink() ?>" target=_blank><b><font size="4"><?php the_title(); ?></font></b></a> ||
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	
	
</div><div id="marquee1" align="center">
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/2448a7bd/cloudflare-static/rocket-loader.min.js" data-cf-nonce="f1a80adeaa41ba9339409f79-"></script><marquee behavior="alternate" onmouseover="this.stop();" onmouseout="this.start();">
	<?php $i = 1; 

$custom_query = new WP_Query('cat=7'); // exclude category 9
while($custom_query->have_posts() && $i < 4) : $custom_query->the_post(); ?>
	<a href="<?php the_permalink() ?>" target=_blank><b><font size="3"><?php the_title(); ?></font></b></a> ||
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	</marquee>
	
	
</div><div id="marquee1" align="center">
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/2448a7bd/cloudflare-static/rocket-loader.min.js" data-cf-nonce="f1a80adeaa41ba9339409f79-"></script><marquee behavior="alternate" onmouseover="this.stop();" onmouseout="this.start();">
	<?php $i = 1; 

$custom_query = new WP_Query('cat=6'); // exclude category 9
while($custom_query->have_posts() && $i < 4) : $custom_query->the_post(); ?>
	
	<a href="<?php the_permalink() ?>" target=_blank><b><font size="3"><?php the_title(); ?></font></b></a> || 
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	</marquee>
</div><div id="marquee1" align="center">
	
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/2448a7bd/cloudflare-static/rocket-loader.min.js" data-cf-nonce="f1a80adeaa41ba9339409f79-"></script><marquee behavior="alternate" onmouseover="this.stop();" onmouseout="this.start();">
	<?php $i = 1; 

$custom_query = new WP_Query('cat=9'); // exclude category 9
while($custom_query->have_posts() && $i < 4) : $custom_query->the_post(); ?>
	<a href="<?php the_permalink() ?>" target=_blank><b><font size="3"><?php the_title(); ?></font></b></a> ||<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?> </marquee>
</div></div>
<br>