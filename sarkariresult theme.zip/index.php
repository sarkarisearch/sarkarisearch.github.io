<?php
get_header(); 
?>
<div align="center">
<div id="facebook">
<a href="YOUR FACEBOOK PAGE URL" target=_blank><font color="#ffffff">Join us on Facebook</font></a></div>
</div>
</div>
<br>
<div align="center">
<table>
<tr>
<td>
	
	<?php $i = 1; 

$custom_query = new WP_Query('cat=7'); // exclude category 9
while($custom_query->have_posts() && $i < 2) : $custom_query->the_post(); ?>
<div id="image1" align="center"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	
	
</td>
<td>
	
	<?php $i = 1; 

$custom_query = new WP_Query('cat=9'); // exclude category 9
while($custom_query->have_posts() && $i < 2) : $custom_query->the_post(); ?>
<div id="image2" align="center"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	
	
</td>
<td>
	
	<?php $i = 1; 

$custom_query = new WP_Query('cat=10'); // exclude category 9
while($custom_query->have_posts() && $i < 2) : $custom_query->the_post(); ?>
<div id="image3" align="center"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	
	
</td>
<td>
	
	<?php $i = 1; 

$custom_query = new WP_Query('cat=8'); // exclude category 9
while($custom_query->have_posts() && $i < 2) : $custom_query->the_post(); ?>
<div id="image4" align="center"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
	<?php $i++;
endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	
	
</td>
</tr>
<tr>
<td>
	
	<?php $i = 1; 

$custom_query = new WP_Query('cat=2'); // exclude category 9
while($custom_query->have_posts() && $i < 2) : $custom_query->the_post(); ?>
<div id="image5" align="center"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	
	
</td>
<td>
	
	<?php $i = 1; 

$custom_query = new WP_Query('cat=6'); // exclude category 9
while($custom_query->have_posts() && $i < 2) : $custom_query->the_post(); ?>
<div id="image6" align="center"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	
	
</td>
<td>
	
	<?php $i = 1; 

$custom_query = new WP_Query('cat=4'); // exclude category 9
while($custom_query->have_posts() && $i < 2) : $custom_query->the_post(); ?>
<div id="image7" align="center"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	
	
</td>
<td>
	
	<?php $i = 1; 

$custom_query = new WP_Query('cat=11'); // exclude category 9
while($custom_query->have_posts() && $i < 2) : $custom_query->the_post(); ?>
<div id="image8" align="center"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></div>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>
	
	
</td>
</tr>
</table></div>
<center><div style="width:75%;">Google Adsense Code Here!</div></center>
<br><br>
<table width="75%" align="center">
<tr valign="top">
<td align="left">
<div id="box1" align="left" style="height:660px">
<div id="heading">
<div id="font" align="center">Result</div>
<div style="margin-top:600px">
<div id="view" align="center"><a href="https://wwwsarkariresultcom.com/latest-sarkari-results/" target=_blank>View More</a></div>
</div>
</div>
<div id="post">
	

	<?php $i = 1; 

$custom_query = new WP_Query('cat=7'); // exclude category 9
while($custom_query->have_posts() && $i < 11) : $custom_query->the_post(); ?>
	<ul>
<li><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></li>
		</ul>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>



</div>
</div>
<br>
<div align="left" id="box2"style="height:320px">
<div id="heading">
<div id="font" align="center">Answer Key</div>
<div style="margin-top:250px">
<div id="view" align="center"><a href="https://wwwsarkariresultcom.com/latest-answer-key-government-exam/" target=_blank>View More</a></div>
</div>
</div>
<div id="post">
<?php $i = 1; 

$custom_query = new WP_Query('cat=9'); // exclude category 9
while($custom_query->have_posts() && $i < 5) : $custom_query->the_post(); ?>
	<ul>
<li><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></li>
		</ul>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>

</div>
<br>

</div>
</td>
<td align="center"><div id="box2" align="center" style="height:660px">
<div id="heading">
<div align="center">Admit Card</div>
<div style="margin-top:600px">
<div id="view" align="center"><a href="https://wwwsarkariresultcom.com/latest-admit-card-call-letter-hall-ticket/" target=_blank>View More</a></div>
</div>
</div>
<div id="post" align="left">
<?php $i = 1; 

$custom_query = new WP_Query('cat=6'); // exclude category 9
while($custom_query->have_posts() && $i < 11) : $custom_query->the_post(); ?>
	<ul>
<li><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></li>
		</ul>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>

</div>
</div>
</div>
<br>
<br>
<div align="center" id="box2" style="margin-top:-20px;height:320px;">
<div id="heading">
<div align="center">Syllabus</div>
<div style="margin-top:250px">
<div id="view" align="center"><a href="https://wwwsarkariresultcom.com/latest-syllabus-exam-pattern/" target=_blank>View More</a></div>
</div>
</div>
<div id="post" align="left">
<?php $i = 1; 

$custom_query = new WP_Query('cat=10'); // exclude category 9
while($custom_query->have_posts() && $i < 5) : $custom_query->the_post(); ?>
	<ul>
<li><a href='<?php the_permalink() ?>'><?php the_title(); ?></a></li>
		</ul>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>

</div>
<br>

</div></td>
<td align="right">
<div id="box1" align="right" style="height:660px">
<div id="heading">
<div id="font" align="center">Latest Jobs</div>
<div style="margin-top:600px">
<div id="view" align="center"><a href="https://wwwsarkariresultcom.com/sarkari-naukri-sarkari-jobs/" target=_blank>View More</a></div>
</div>
</div>
<div id="post" align="left">
<?php $i = 1; 

$custom_query = new WP_Query('cat=8'); // exclude category 9
while($custom_query->have_posts() && $i < 11) : $custom_query->the_post(); ?>
	<ul>
<li><a href='<?php the_permalink() ?>'><?php the_title(); ?></a></li>
		</ul>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>


</div>
</div>
</div>
<br>
<div align="center" id="box2" style="height:320px; ">
<div id="heading">
<div align="center">Admission</div>
<div style="margin-top:250px">
<div id="view" align="center"><a href="https://wwwsarkariresultcom.com/sarkari-naukri-sarkari-jobs/" target=_blank>View More</a></div>
</div>
</div>
<div id="post" align="left">
<?php $i = 1; 

$custom_query = new WP_Query('cat=11'); // exclude category 9
while($custom_query->have_posts() && $i < 5) : $custom_query->the_post(); ?>
	<ul>
<li><a href='<?php the_permalink() ?>'><?php the_title(); ?></a></li>
		</ul>
	<?php $i++; endwhile; ?>
<?php wp_reset_postdata(); // reset the query ?>

</div>
</div>
</div>
</div></td>
</tr>
</table>
<center><div style="width:75%;">Google Adsense Code Here!
	</div></center>
<center>DMCA CODE</center>
<br><br>

</html>

<?php get_footer(); ?>
